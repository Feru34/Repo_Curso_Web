import logo from './logo.svg';
import './App.css';
import { useState } from 'react';
import Button from 'react-bootstrap/Button';
import Form from 'react-bootstrap/Form';
function App() {

  const setEmailError = "";
  const setPasswordError = "";
  const [formValues, setFormValues] = useState({email:"", password:"",
  favClass:"1"})

  const handleEmailChange = (e) => {
    const emailValue = e.target.value;
    if (emailValue.includes('@') && emailValue.length >= 1) {
      // Verificar si el correo contiene "@" y tiene al menos 1 carácter
      setEmailError('');
      setFormValues({ ...formValues, email: emailValue });
    } else {
      setEmailError('El correo debe contener "@"');
    }
  };
  
  const handlePasswordChange = (e) => {
    const passwordValue = e.target.value;
    if (passwordValue.length >= 8) {
      // Verificar si la contraseña tiene al menos 8 caracteres
      setPasswordError('');
      setFormValues({ ...formValues, password: passwordValue });
    } else {
      setPasswordError('La contraseña debe tener al menos 8 caracteres');
    }
  };
  
  const handleSelectChange = ((e) => {
  setFormValues({...formValues, favClass: e.target.value})
  });

  const clickSubmit = (() => {
    //Call fetch
    alert(JSON.stringify(formValues))
    })
      


return (
<div>
  <h1>Ejemplo de formularios!</h1>
  <Form>
  <Form.Group className="mb-6" controlId="formBasicEmail">
    <Form.Label>Email address</Form.Label>
    <Form.Control type="email" placeholder="Enter email" onChange = {handleEmailChange} value={formValues.email}/>
    <Form.Text className="text-muted">We'll never share your email with anyone
else.</Form.Text>
  </Form.Group>

    <Form.Group className="mb-3" controlId="formBasicPassword">
    <Form.Label>Password</Form.Label>
    <Form.Control type="password" placeholder="Password" onChange = {handlePasswordChange} value={formValues.password}/>
  <Form.Text className="text-muted">Your password should be have numbers and
  letters and should be at least 9 char long</Form.Text>
  </Form.Group>
    <Form.Group className="mb-3" controlId="formBasicCheckbox" onChange = {handleSelectChange} value={formValues.favClass}>
      <Form.Label>Favorite Class</Form.Label>
      <Form.Select>
        <option value="1">ISIS3710</option>
        <option value="2">Programación con tecnologias web</option>
      </Form.Select>
  </Form.Group>
  <Button variant="primary" onClick={clickSubmit}>
    Submit
  </Button>
  </Form>
</div>
);
}

export default App;
