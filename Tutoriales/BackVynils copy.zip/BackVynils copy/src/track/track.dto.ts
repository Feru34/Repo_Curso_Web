export class TrackDTO {
    readonly id: number;
    readonly name: string;
    readonly duration: string;
}