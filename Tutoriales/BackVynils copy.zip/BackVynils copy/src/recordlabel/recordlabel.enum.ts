export enum RECORD_LABEL {
    SONY = "Sony Music",
    EMI = "EMI",
    FUENTES = "Discos Fuentes",
    ELEKTRA = "Elektra",
    FANIA = "Fania Records"
}