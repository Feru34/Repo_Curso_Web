export enum GENRE {
    CLASSICAL = "Classical",
    SALSA = "Salsa",
    ROCK = "Rock",
    FOLK = "Folk"
}