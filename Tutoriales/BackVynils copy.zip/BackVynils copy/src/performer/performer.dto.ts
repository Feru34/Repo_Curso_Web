export class PerformerDTO {
    readonly id: number;
    readonly name: string;
    readonly image: string;
    readonly description: string;
}