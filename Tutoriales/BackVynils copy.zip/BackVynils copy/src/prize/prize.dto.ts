export class PrizeDTO {
    readonly id: number;
    readonly name: string;
    readonly description: string;
    readonly organization: string;
}