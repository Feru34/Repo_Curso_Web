export enum ALBUM_STATUS {
    ACTIVE = "Active",
    INACTIVE = "Inactive"
}