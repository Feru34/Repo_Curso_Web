export class CollectorDTO {
    readonly id: number;
    readonly name: string;
    readonly telephone: string;
    readonly email: string;
}