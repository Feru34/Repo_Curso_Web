export class PerformerPrizeDTO {
    readonly premiationDate: Date;
}