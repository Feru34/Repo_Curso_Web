import { PerformerDTO } from "../performer/performer.dto";

export class BandDTO extends PerformerDTO {

    readonly creationDate: Date;

}